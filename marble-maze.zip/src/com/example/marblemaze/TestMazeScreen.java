package com.example.marblemaze;

// -------------------------------------------------------------------------
/**
 *  tests the screen
 *
 *  @author Nicholas Kilmer (nkilmer8)
 *  @version 2013.12.08
 */
public class TestMazeScreen
{

}
